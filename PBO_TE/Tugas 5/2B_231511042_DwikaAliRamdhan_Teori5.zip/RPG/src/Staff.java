// Staff.java
public class Staff extends Weapon {
    public Staff() {
        super("Magic", "Staff of Eternity");
    }
}
