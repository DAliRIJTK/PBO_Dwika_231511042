// Sword.java
public class Sword extends Weapon {
    public Sword() {
       super ("Melee", "Blade of Destruction");
    }
}
