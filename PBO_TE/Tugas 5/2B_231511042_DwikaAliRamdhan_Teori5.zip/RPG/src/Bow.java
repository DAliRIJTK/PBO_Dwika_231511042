// Bow.java
public class Bow extends Weapon {
    public Bow() {
        super("Ranged", "Shadowstrike Bow");
    }
}
